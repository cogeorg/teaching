def multiply(int1, int2):

    return int1 * int2
