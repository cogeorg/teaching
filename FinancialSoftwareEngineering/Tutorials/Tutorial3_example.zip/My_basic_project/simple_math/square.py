def square(int1):

    return int1**2
