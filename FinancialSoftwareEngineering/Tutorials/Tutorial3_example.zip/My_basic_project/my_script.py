from simple_math import square
from advanced_math import differentiation

print(square.square(2))
differentiation.differentiation()
