def differentiation():
	print("Hello from differentiation")