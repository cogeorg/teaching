// ---------------- Variables and data types ---------------- //

var firstName = 'John';
console.log(firstName);

var lastName = 'Smith';
var age = 28;

var fullAge = true;
console.log(fullAge);


// Type coercion
console.log(firstName + ' ' + lastName + ' is ' + age + ' years old ');
alert(firstName + ' ' + lastName + ' is ' + age + ' years old ');


if (age < 18) {
    console.log(firstName + ' is at school');
} else if (age >= 18 && age < 24) {
    console.log(firstName + ' is at university.');
} else if (age >= 24 && age < 65) {
    console.log(firstName + ' is working');
} else {
    console.log(firstName + ' is retired');
}

//Introduction switch

var job = "developer";

switch (job) {
    case 'developer':
        console.log(firstName + ' is a dev');
        break;
    case 'academic':
        console.log(firstName + ' is an academi');
        break;
    case 'accountant':
        console.log(firstName + ' is an accountant');
        break;
    default:
        console.log(firstName + ' is unemployed');
}

// For notation

for (i = 0; i < 5; i = i + 1) {
    console.log(i);
}

// Arrays

var names = ['John', 'Marc', 'Jane'];
var years = new Array(1990, 1969, 1948);

console.log(names[2]);
console.log(names.length);

names[names.length] = 'Mary';

function tipCalculator(bill) {
    var percentage;
    if (bill < 50) {
        percentage = .2;
    } else if (bill >= 50 && bill < 200) {
        percentage = .15;
    } else {
        percentage = .1;
    }
    return percentage * bill;
}

// Creating an object

var john = {
    firstName: 'John',
    lastName: 'Smith',
    birthYear: 1990,
    family: ['Jane', 'Marc'],
    job: 'developer',
};

console.log(john.firstName);
console.log(john['lastName']);

//Methods


var john = {
    firstName: 'John',
    lastName: 'Smith',
    birthYear: 1990,
    family: ['Jane', 'Marc'],
    job: 'developer',
    calcAge: function() {
        this.age = 2018 - this.birthYear;
    }
};

/*
alert("Welcome to my website")
var name = prompt("What is your name?")
alert("Nice to meet you, " + name)
*/
